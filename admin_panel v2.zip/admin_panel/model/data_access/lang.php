<?php
/**
 * Created by PhpStorm.
 * User: peymanvalikhanli
 * Date: 3/4/17 AD
 * Time: 20:58
 */
class lang{

    public static $register_data = 'اطلاعات با موفقیت ثبت شد';
    public static $success       = 'success';  //'اطلاعات با موفقیت ثبت شد';
    public static $failed        = 'error on server';
    public static $invalid_data  = 'invalid data'; //'اطلاعات معتبر نمی باشد';
    public static $is_not_login  = 'ایمیل یا رمزعبور معتبر نمی باشد';
    public static $last_registered_data = 'قبلا این اطلاعات ثبت شده است';
    public static $is_not_set_profile   = 'در ثبت اطلاعات شما مشکل پیش آمده است لطفا دورباره تلاش کنید';
    public static $error   = 'خطا!';
    public static $message = 'پیغام';
    public static $invalid_device = 'invalid device';

}