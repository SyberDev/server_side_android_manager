<?php
/**
 * Created by PhpStorm.
 * User: peymanvalikhanli
 * Date: 6/14/17 AD
 * Time: 13:32
 */

require_once "filing.php";

echo "hi peyman test file class <br> <hr> <br> ";

//echo filing::create_dir("peyman $ &DSA ksfdslkfj _)( <> ppp ");

//$result =filing::open_file("peyman.txt");

//echo filing::rename_file("peyman.txt","ali.txt");
//echo filing::copy_file("peyman.txt","ali.txt");
//echo filing::remove_file("ali.txt");
//echo filing::copy_dir("ali_ali" , "asghar");
echo filing::remove_dir("asghar");
