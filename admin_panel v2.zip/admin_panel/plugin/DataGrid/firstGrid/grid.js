/**
 * Created by NP on 5/24/2017.
 */
function PSCO_grid() {

    this.develop_mode = false;
    //___________global property of class
    this.name = undefined;
    this.table_class = undefined;
    this.ContainerID = 'PGrid';
    this.RightToLeft = true;
    this.type = undefined;
    this.button = undefined; // [{name: "" , type:'none' , attribute:[{name , value}] , ClassName:""}]
    this.cols = undefined; // [{name:"" , type : "" , hidden : 'true' , sortBy: 'true' , slect : 'true' }]
    this.actions = undefined; // [{name: "" , type:'none' , attribute:[{name , value}] , ClassName:""}]
    this.rows = undefined; //[{name: "" , value:"" , type :"" }]
    this.data = undefined; // {data payload }
    this.row_Selected = undefined; //[1,2,3,4,....,n]
    this.paging_row_count = 10;
    this.currentPage = 1;
    this.find_in_server = false;
    this.server_finder_function = undefined;

    this.render = function () {

        var Container = document.getElementById(this.ContainerID);
        Container.classList.add('PGrid');

        var i, a, button, tr, td, cols, table; //____ varable

        //________________ table Classes
        table = document.createElement('table');
        //_____ set Table Direction
        if (this.RightToLeft) {
            table.style.direction = 'rtl';
        }
        else {
            table.style.direction = 'ltr';
        }
        //_____ setTable Classes
        if (this.table_class == undefined) {
            if (this.table_class == undefined) {
                table.setAttribute('class', 'table table-bordered table-responsive table-hover table-striped table-condensed text-center');
            } else {
                table.setAttribute('class', this.table_class);
            }

            // type for tmpalte data grid exm: mail data grid or global format grid
            if (this.type != undefined && this.type != null && this.type.trim() != 'none'.trim()) {

            }

            //_____create button of grid
            if (this.button != undefined && this.button != null) {
                //______________ Create Btn Divider
                var BtnDivider = document.createElement('div');
                BtnDivider.setAttribute('class', 'col-xs-3 pull-right');

                for (i = 0; i < this.button.length; i++) {

                    button = document.createElement('span');

                    //________ set Name
                    if (this.button[i].name != '' && this.button[i].name != null) {
                        button.innerText = this.button[i].name;
                    }

                    if (this.button[i].attribute != '' && this.button[i].attribute != null) {
                        for (a = 0; a < this.button[i].attribute.length; a++) {
                            button.setAttribute(this.button[i].attribute[a].name, this.button[i].attribute[a].value);
                        }
                    }

                    //________ set Class Of Btn
                    button.classList.add('btn');
                    if (this.button[i].ClassName == '' || this.button[i].ClassName == null) {
                        button.classList.add('btn-default');
                    } else {
                        var clName = this.button[i].ClassName.split(' ');
                        for (var c = 0; c < clName.length; c++) {
                            button.classList.add(clName[c]);
                        }
                    }

                    //________ set Type Of Btn
                    if (this.button[i].type == '' || this.button[i].type == null) {

                    } else {

                    }
                    BtnDivider.appendChild(button);
                }
                Container.appendChild(BtnDivider);

            }
            //_____create cols of grid
            if (this.cols != undefined && this.cols != null) {

                var THead = document.createElement('thead'); //______ set thead
                tr = document.createElement('tr'); // _____ set tr

                for (i = 0; i < this.cols.length; i++) {
                    cols = document.createElement('th'); // ___ set th
                    try {
                        cols.innerText = this.cols[i].name; // ___ set th name
                    } catch (er) {
                    }
                    if (this.cols[i].hidden != undefined && this.cols[i].hidden == true) {
                        cols.style.display = 'none';
                    }
                    tr.appendChild(cols);

                }
                /* type of cols set in Data */
                THead.appendChild(tr);
                table.appendChild(THead);
            }
            //_____create action button on more rows of grid
            if (this.actions != undefined && this.actions != null) {
                for (i = 0; i < this.actions.length; i++) {
                    var action = this.actions[i];
                    var Actionicon = document.createElement('span'); //____ CREATE ACTION span
                    try {
                        Actionicon.innerText = action.name;
                    } catch (er) {
                    }

                    for (a = 0; a < action.attribute.length; a++) {
                        Actionicon.setAttribute(action.attribute.name, action.attribute.value); //_____ set Attribute
                    }
                    if (action.ClassName != undefined && action.ClassName != '') {
                        var Classes = action.ClassName;
                        Classes = Classes.split(' ');
                        for (a = 0; a < Classes.length; a++) {
                            action.classList.add(Classes[a]);
                        }
                    }
                }

            }

            /*     //_____save Data in row with Row Format !!! TODO: must be understand what this Fucking Row
             if (this.data != undefined && this.data != null) {
             for (i = 0; i < this.data.length; i++) {
             var Data = this.data[i];
             var DataKeys = Object.keys(Data); //____ get Cols key
             for (a = 0; a < DataKeys.length; a++) {

             }
             }
             }
             */
            //_____create rows of grid
            if (this.data != undefined && this.data != null) {

                // TODO: set rows and filling the table
                var tbody = document.createElement('tbody');
                this.rows = [];
                i = this.currentPage - 1;
                for (; i < this.paging_row_count; i++) {
                    try {

                        var row = {}; //____ set this.Data in This.Row

                        tr = document.createElement('tr'); //___ set tr
                        tr.setAttribute('id', 'tr_' + this.data[i].id); //___set tr id
                        tr.setAttribute('onclick', 'tr_' + "SelectedThisRow('this')"); //___set tr Selected function

                        var Data = this.data[i];
                        var DataKeys = Object.keys(Data); //____ get Cols key

                        for (a = 0; a < DataKeys.length; a++) {

                            row[DataKeys[a]] = Data[DataKeys[a]]; //____ set cols

                            td = document.createElement('td');

                            if (this.cols[a].hidden != undefined && this.cols[a].hidden == true) { //________ if hidden is true !
                                td.style.display = 'none';
                            }

                            var ColsType = col_type(this.cols[a].type); //____ type of cols
                            if (ColsType != 'Text') {
                                try {
                                    td.appendChild(ColsType); //____ set element in td
                                } catch (er) {
                                }
                            } else {
                                td.innerText = Data[DataKeys[a]]; //____ set text of td
                            }
                            tr.appendChild(td);
                        }
                        tbody.appendChild(tr);

                        this.rows.push(row);
                    } catch (err) {
                    }
                }

                table.appendChild(tbody);
            }
            Container.appendChild(table);

            //_______ create paging of the grid
            if (this.rows != undefined && this.rows != null && this.rows.length > (this.paging_row_count * 1)) {
                var pageBtn_number = this.data.length / this.paging_row_count;
                if (!Number.isInteger(pageBtn_number)) {
                    pageBtn_number = parseInt(pageBtn_number) + 1;
                }
                BtnDivider = document.createElement('div');
                BtnDivider.setAttribute('class', 'panel-footer page-divider pull-right');
                for (i = 0; i < pageBtn_number; i++) {
                    var btn = document.createElement('span');
                    btn.setAttribute('class', 'btn btn-primary');
                    BtnDivider.appendChild(btn);
                }
                Container.appendChild(BtnDivider);
            }
            //_____ create fast finder grid
            //TODO: create colaps of finder on table header
            //TODO: set function on
            if (this.find_in_server) {
                //
            } else {
                // call finder function
            }

        }
    };

    this.finder = function () {


    };

    var button_type = function (type) {

        switch (type) {

            case 'addnew':


                break;

            case 'edit':
            case 'update':

                break;
            case 'delete':


                break;

            case 'none':
            default:


        }
    };

    //___________ tr onclick
    var SelectedThisRow = function (Trelem) {
        var Selectedid = Trelem.getAttribute('id');
        Selectedid.split('_');
        this.row_Selected = Selectedid[1];
    };

    var col_type = function (type) {
        var result;
        result = document.createElement('input');
        switch (type) {

            case 'check':
            case 'Check':
            case 'CheckBox':
            case 'Check_Box':
            case 'check_box':
                result.setAttribute('type', 'checkbox');


                break;

            case 'calender':
            case 'Calender':

                break;

            case 'radio':
            case 'Radio':
                result.setAttribute('type', 'radio');
                break;

            case 'toggle':
            case 'Toggle':
            case 'toggle_button':
            case 'togglebutton':
            case 'toggleButton':

                break;
            case 'button':
            case 'Button':
                result.setAttribute('type', 'button');

                break;

            case 'text':
            case 'Text':
            case '':
            default:
                result = 'Text';
                // TODO: return text mode on row cell
                break;
        }
        return result;

    }

}
