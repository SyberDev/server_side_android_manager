/**
 * Created by peymanvalikhanli on 3/5/17 AD.
 */

function datavalid(){

}

datavalid.prototype.isnull = function(data){if(data == null || data == undefined || data == ''){return true ;}else{return false}}