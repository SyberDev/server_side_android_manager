var SelectedDeviceID ;
var SmsGrid;
var DeviceGrid;

/* Received Sms */
function loadrecived(actName, btn) {
    SmsGrid = '';
    SmsGrid = new PSCO_grid('SmsGrid');
    document.getElementById(SmsGrid.ContainerID).innerHTML = '';
    SmsGrid.cols = [
        {
            name: 'createdby',
            hidden: true
        },
        {
            name: 'creationdate',
            hidden: true
        },
        {
            name: 'deviceid',
            hidden: true
        },
        {
            name: 'id',
            hidden: true
        },
        {
            name: 'number',
            type: 'text'
        },
        {
            name: 'registerDate',
            type: 'text'
        },
        {
            name: 'reqnumber',
            hidden: true
        },
        {
            name: 'smsId',
            hidden: true
        },
        {
            name: 'status',
            hidden: true
        },
        {
            name: 'text',
            hidden: true
        },
        {
            name: 'type',
            hidden: true
        }
    ];
    SmsGrid.actions = [{
        name: 'ShowText',
        attribute: [{name: 'onclick', value: 'ShowText(this)'}],
        ClassName: 'glyphicon glyphicon-envelope'
    }];
    SmsGrid.button = btn;
    ajax.sender_data_callback({act: actName}, SetData);
}
function SetData(data) {
    SmsGrid.data = data;
    SmsGrid.render();
}

//____ for show message
function ShowText(elem) {
    elem = elem.parentElement.parentElement.parentElement;
    elem = elem.getAttribute('data-rowid');
    elem = elem.split('_');
    elem = elem[1];
    var Text = SmsGrid.rows[elem]['text'];

    $('#ModalBody').text(Text);
    $('#TextModal').modal('show');
}

function AutoRefresh(elem, funcName, actName, btn) {
    var interValSms;
    if (elem.checked == true) {
        interValSms = setInterval(function () {
            funcName(actName, btn);
        }, 180000);

    } else {
        clearInterval(interValSms);
    }
}


/* smsSent */
function Newsms() {
    var Modal = document.getElementById('ModalBody');
    Modal.innerHTML = '';
    var inputs = '<h2>' + __lang.translate('sent_New_Sms') + '</h2>' +
        '<label style="display: block"><span>' + __lang.translate('number') + '</span><br/><input id="number" type="number" style="max-width: 60%;     display: inline-block;" class="form-control"><div class="btn btn-primary" onclick="GetPhoneBook()">' + __lang.translate('phone_book') + '</div><div id="phoneBook"> <div id="phoneBookDivider"><i class="glyphicon glyphicon-remove" onclick="hidePhone()"></i> </div> </div></label>' +
        '<label style="display: block"><span>' + __lang.translate('text') + '</span><br/><textarea cols="5" rows="10" id="text"></textarea></label>' +
        '<div class="btn btn-success" onclick="sendSms()">' + __lang.translate('send') + '</div> ';
    Modal.innerHTML = inputs;
    $('#TextModal').modal('show');
}
function CreatePhoneBook(data) {
    var dataKeys = Object.keys(data);
    var ul = document.createElement('ul');
    var li;
    for (var i = 0; i < dataKeys.length; i++) {
        li = document.createElement('li');
        li.setAttribute('onclick' , 'SelectthisPhone(this)');
        var name = document.createElement('h5');
        name.innerText = data[dataKeys[i]].name;
        var phone = document.createElement('h6');
        phone.innerText = data[dataKeys[i]].number;
        li.appendChild(name);
        li.appendChild(phone);
        ul.appendChild(li);
    }
    var phoneBookDivider = document.getElementById('phoneBookDivider');
    phoneBookDivider.innerHTML = '';
    phoneBookDivider.appendChild(ul);
    showPhone();
}
function sendSms() {
    var number = document.getElementById('number').value;
    var text = document.getElementById('text').innerText;
    ajax.sender_data_callback({act:'sendSms' , text:text , number:number , deviceid:SelectedDeviceID} , console.log);
}
function SelectthisPhone(elem){
    document.getElementById('number').value = elem.children[1].innerText;
    hidePhone();
}
function GetPhoneBook(){
    ajax.sender_data_callback({act:'get_contact'} , CreatePhoneBook ) ;
}
function showPhone() {
    document.getElementById('phoneBook').style.width = '40%';
}
function hidePhone(){
    document.getElementById('phoneBook').style.cssText = '';
}

/* Devices */
function loadDevices() {
    DeviceGrid = '';
    DeviceGrid = new PSCO_grid('DeviceGrid');

    DeviceGrid.row_selectedFunc = 'selectDevice';
    DeviceGrid.cols = [
        {name: 'IMEI'},
        {name: 'createdby', hidden: true},
        {name: 'creationdate', hidden: true},
        {name: 'id', hidden: true},
        {name: 'name'}
    ];
    ajax.sender_data_callback({act: 'get_devices'}, SetDevicesData);

}


function selectDevice() {
    SelectedDeviceID = DeviceGrid.row_Selected;
}



function SetDevicesData(data) {
    DeviceGrid.data = data;
    DeviceGrid.render();
}