/**
 * Created by peymanvalikhanli on 4/17/17 AD.
 */
function get_elem_id(id){return document.getElementById(id);}
function get_elem_name(name){return document.getElementsByName(name);}
function get_elem_class(classname){return document.getElementsByClassName(classname);}

function set_elem(elem){return document.createElement(elem);}
